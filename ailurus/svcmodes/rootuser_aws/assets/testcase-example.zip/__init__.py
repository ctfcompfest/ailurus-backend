from .tests import run_testcase
from typing import List, TypedDict, Dict
import datetime

class ServiceType(TypedDict):
    id: int
    team_id: int
    challenge_id: int
    order: int
    secret: str
    detail: str # JSON format service detail configuration
    time_created: datetime.datetime

class FlagType(TypedDict):
    id: int
    team_id: int
    challenge_id: int
    round: int
    tick: int
    value: str
    order: int # flag order number (0: root flag, 1: user flag).

def main(services: List[ServiceType], flags: List[FlagType]) -> Dict:
    return run_testcase()