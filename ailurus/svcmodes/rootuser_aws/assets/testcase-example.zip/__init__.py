from .tests import run_testcase
from typing import List, TypedDict, Dict, Tuple, Map, Any
import datetime

class ServiceType(TypedDict):
    id: int
    team_id: int
    challenge_id: int
    order: int
    secret: str
    detail: Map[str, Any]
    time_created: datetime.datetime

class FlagType(TypedDict):
    id: int
    team_id: int
    challenge_id: int
    round: int
    tick: int
    value: str
    order: int # flag order number (0: root flag, 1: user flag).

def main(services: List[ServiceType], flags: List[FlagType]) -> Tuple[bool, Dict]:
    service_detail = services[0]["detail"]
    
    credentials = service_detail["checker"]
    aws_stack_name = service_detail["stack_name"]
    ip = credentials["ip"]
    username = credentials["username"]
    privkey = credentials["private_key"]
    instance_id = credentials["instance_id"]
    
    return run_testcase()